package MPD::PrimerDesign;

# ABSTRACT: This package is used to for multiplex primer design.

use 5.10.0;

use Moose 2;
use MooseX::Types::Path::Tiny qw/ AbsPath AbsFile File /;
use namespace::autoclean;

use Carp qw/ croak /;
use Excel::Writer::XLSX;
use Path::Tiny;
use Type::Params qw/ compile /;
use Types::Standard qw/ :types /;
use Time::localtime;

use Data::Dump qw/ dump /; # for debugging

use MPD::Bed;
use MPD::isPcr;
use MPD::Primer;
use MPD::Psl;

our $VERSION = '0.001';
my $time_now = ctime();

has Bed => ( is => 'ro', isa => 'MPD::Bed', required => 1 );

# for debugging
has RunIsPcr => ( is => 'ro', isa => 'Bool', default => 1 );

# required files
has isPcrBinary => ( is => 'ro', isa => AbsFile, coerce => 1, required => 1, );
has TwoBitFile  => ( is => 'ro', isa => AbsFile, coerce => 1, required => 1, );
has MpdBinary   => ( is => 'ro', isa => AbsFile, coerce => 1, required => 1, );
has MpdIdx      => ( is => 'ro', isa => File,    coerce => 1, required => 1, );
has dbSnpIdx    => ( is => 'ro', isa => File,    coerce => 1, required => 1, );
has OutExt => ( is => 'ro', isa => 'Str', required => 1, );

# pcr attrs
has PrimerSizeMin => ( is => 'ro', isa => 'Int', default => 17,  required => 1 );
has PrimerSizeMax => ( is => 'ro', isa => 'Int', default => 27,  required => 1 );
has AmpSizeMin    => ( is => 'ro', isa => 'Int', default => 150, required => 1 );
has AmpSizeMax    => ( is => 'ro', isa => 'Int', default => 250, required => 1 );
has GcMin         => ( is => 'ro', isa => 'Num', default => 0.3, required => 1 );
has GcMax         => ( is => 'ro', isa => 'Num', default => 0.7, required => 1 );
has TmMin         => ( is => 'ro', isa => 'Num', default => 57,  required => 1 );
has TmMax         => ( is => 'ro', isa => 'Num', default => 62,  required => 1 );
has PoolMax       => ( is => 'ro', isa => 'Int', default => 10,  required => 1 );
has PadSize       => ( is => 'ro', isa => 'Int', default => 60,  required => 1 );
has TmStep        => ( is => 'ro', isa => 'Num', default => 0.5, required => 1 );

# Temporary Files
my $bedPt    = Path::Tiny->tempfile();
my $tmpCmdPt = Path::Tiny->tempfile();
my $primerPt = Path::Tiny->tempfile();
my $isPcrPt  = Path::Tiny->tempfile();

sub SayMppCmd {
  state $check = compile( Object, Str );
  my ( $self, $outFile ) = $check->(@_);

  my $bedFh = $bedPt->filehandle(">");
  say {$bedFh} $self->Bed->Entries_as_BedFile();

  my $cmd = join "\n", "d", $outFile, $self->MpdIdx, $self->dbSnpIdx,
    $bedPt->stringify, $self->PrimerSizeMin, $self->PrimerSizeMax, $self->AmpSizeMin,
    $self->AmpSizeMax, $self->GcMin, $self->GcMax, $self->TmMin, $self->TmMax,
    $self->PoolMax, $self->PadSize, $self->TmStep;
  return $cmd;
}

sub RunMpp {
  state $check = compile( Object, Str );
  my ( $self, $outFile ) = $check->(@_);

  my $o = path($outFile);

  # create temp file with MPD commands
  my $tmpCmdFh = $tmpCmdPt->filehandle(">");
  say {$tmpCmdFh} $self->SayMppCmd( $o->stringify );

  my $cmd = sprintf( "%s < %s\n", $self->MpdBinary, $tmpCmdPt->stringify );
  my $err = qx/$cmd/;

  if ( $o->is_file ) {
    return 1;
  }
  else {
    return;
  }
}

sub UniqPrimers {
  my $self = shift;

  my $ok = $self->RunMpp( $primerPt->stringify );
  if ( !$ok ) {
    my $msg = "Error running mpd binary";
    croak $msg;
  }

  my $primer = MPD::Primer->new( $primerPt->stringify );
  if ( !$self->RunIsPcr ) {
    return $primer;
  }

  # say $primerPt->slurp;

  my $isPcr = MPD::isPcr->new(
    {
      PrimerFile       => $primerPt->stringify,
      PrimerFileFormat => 'mpp',
      isPcrBinary      => $self->isPcrBinary,
      TwoBitFile       => $self->TwoBitFile,
      OutFile          => $isPcrPt->stringify,
    }
  );
  if ( !$isPcr->Run() ) {
    return;
  }

  # Remove Degenerate primers
  my $psl     = MPD::Psl->new( $isPcrPt->stringify );
  my $dupAref = $psl->DegenerateMatches();
  if ( !$dupAref ) {
    return MPD::Primer->new( $primerPt->stringify );
  }
  my %degenMatches = map { $_ => 1 } @$dupAref;
  my $uniqPrimerObj = $primer->RemovePrimers( [ sort keys %degenMatches ] );

  #say dump( { uniqPrimerObj => $uniqPrimerObj, degeneratePrimers => \%degenMatches } );

  return $uniqPrimerObj;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

MPD::PrimerDesign - This package is used to for multiplex primer design.

=head1 VERSION

version 0.001

=head1 AUTHOR

Thomas Wingo <thomas.wingo@emory.edu>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2016 by Thomas Wingo.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
