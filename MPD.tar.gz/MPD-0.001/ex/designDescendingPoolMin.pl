#!/usr/bin/env perl
# Name:           ex/design.pl
# Date Created:   Wed Mar  9 15:36:28 2016
# Date Modified:  Wed Mar  9 15:36:28 2016
# By:             TS Wingo
#
# Description:

use 5.10.0;
use warnings;
use strict;
use Getopt::Long;
use MPD;
use Path::Tiny;

# variables
my ( $verbose, $act, $dir, $prn, $poolMin, $bed_file, $config_file, $out_ext );

# get options
die
  "Usage: $0 [-v] [-a] -b <bed file> -c <config file> -d <output Dir> -o <out_ext>\n"
  unless GetOptions(
  'v|verbose'  => \$verbose,
  'a|act'      => \$act,
  'b|bed=s'    => \$bed_file,
  'c|config=s' => \$config_file,
  'o|out=s'    => \$out_ext,
  'd|dir=s'    => \$dir,
  )
  and $bed_file
  and $config_file
  and $out_ext;
$verbose = 1 unless $act;

$dir = path($dir);

if ( !$dir->is_dir ) {
  $dir->mkpath();
}

my $thisBedFile;
my @poolMins = ( 4 .. 10 );
for ( my $i = $#poolMins; $i > 0; $i-- ) {

  my ( $thisExt, $priorExt, $thisBedFile );

  if ( $i == $#poolMins ) {
    $thisExt     = $bed_file;
    $thisBedFile = $bed_file;
  }
  else {
    $thisExt  = sprintf( "%s-%02d", $out_ext, $poolMins[$i] );
    $priorExt = sprintf( "%s-%02d", $out_ext, $poolMins[ $i + 1 ] );
    my $bedPt = $dir->child("$priorExt.uncovered.bed");

    $thisBedFile = $bedPt->stringify();

    # check bedfile
    if ( $verbose && !$act ) {
      $bedPt->touch();
    }
    elsif ( !$bedPt->is_file ) {
      $thisBedFile = $bed_file;
    }
  }

  my $minPool = $poolMins[$i];

  say join "\t", $thisExt, $thisBedFile, $minPool;

  if ( !path($thisBedFile)->is_file() ) {
    die "Did not find expected bed file: $thisBedFile";
  }

  my $m = MPD->new_with_config(
    {
      configfile  => $config_file,
      BedFile     => $thisBedFile,
      OutExt      => $thisExt,
      OutDir      => $dir->stringify(),
      InitTmMin   => 58,
      InitTmMax   => 61,
      PoolMin     => $poolMins[$i],
      Debug       => $verbose,
      IterMax     => 2,
      RunIsPcr    => 1,
      Act         => $act,
      ProjectName => $out_ext,
      FwdAdapter  => 'ACACTGACGACATGGTTCTACA',
      RevAdapter  => 'TACGGTAGCAGAGACTTGGTCT',
      Offset      => 0,
      Randomize   => 1,
    }
  );
  $m->RunAll() if $act;
}
