package MPD::PrimerQc;

# ABSTRACT: This package manipulates MPD-designed primers.

use 5.10.0;

use Moose 2;
use namespace::autoclean;

use Carp qw/ croak /;
use Path::Tiny;
use Type::Params qw/ compile /;
use Types::Standard qw/ :types /;
use Scalar::Util qw/ reftype looks_like_number /;

use Data::Dump qw/ dump /; # for debugging

use MPD::Bed;
use MPD::Bed::Covered;
use MPD::Covered;
use MPD::Primer::Raw;
use MPD::Seq;

our $VERSION = '0.001';

has Primers => (
  traits  => ['Array'],
  is      => 'ro',
  isa     => 'ArrayRef[MPD::Primer::Raw]',
  handles => {
    all_primers   => 'elements',
    no_primers    => 'is_empty',
    count_primers => 'count',
    add_primer    => 'push',
  },
  default => sub { [] },
);

sub BadPrimerPerPool {
  my ( $self, $file ) = @_;

  my $ampForBadPrimerHref = $self->_readBadPrimerFile($file);

  my ( %primerCount, %badPrimer );
  for my $p ( $self->all_primers ) {
    $primerCount{ $p->Pool }++;
    if ( exists $ampForBadPrimerHref->{ $p->Product() } ) {
      $badPrimer{ $p->Pool }++;
    }
  }

  say join "\t", (qw/pool primer_count bad_primer percent_bad/);
  for my $pool ( sort { $a <=> $b } keys %primerCount ) {
    if ( exists $badPrimer{$pool} ) {
      say join "\t", $pool, $primerCount{$pool}, $badPrimer{$pool},
        ( $badPrimer{$pool} / $primerCount{$pool} );
    }
    else {
      say join "\t", $pool, $primerCount{$pool}, 0, 0;
    }
  }
}

# BUILDARGS takes either a hash reference or string, which is a primer file
sub BUILDARGS {
  my $class = shift;

  if ( scalar @_ == 1 ) {
    if ( !reftype( $_[0] ) ) {
      # assumption is that you passed a file be read and used to create
      # recall, reftype returns undef for string values

      my $file        = $_[0];
      my $primersAref = $class->_ReadPrimerFile($file);
      return $class->SUPER::BUILDARGS( { Primers => $primersAref } );
    }
    elsif ( reftype( $_[0] ) eq "ARRAY" ) {
      return $class->SUPER::BUILDARGS( { Primers => $_[0] } );
    }
    elsif ( reftype( $_[0] ) eq "HASH" ) {
      return $class->SUPER::BUILDARGS( $_[0] );
    }
    else {
      my $msg =
        "Error: Construct MPD::Primer object with either a hashref, arrayref of hashrefs, or primer file";
      croak($msg);
    }
  }
  else {
    my $msg =
      "Error: Construct MPD::Primer object with either a hashref, arrayref of hashrefs, or primer file";
    croak($msg);
  }
}

sub _readBadPrimerFile {
  my ( $self, $file ) = @_;

  my %productForBadPrimer;

  my $fh = path($file)->filehandle();
  my (%header);

  while (<$fh>) {
    chomp $_;
    my @fields = split /\t/, $_;
    if ( !%header ) {
      %header = map { $fields[$_] => $_ } ( 0 .. $#fields );
      next;
    }
    my %data = map { $_ => $fields[ $header{$_} ] } ( keys %header );
    $productForBadPrimer{ $data{Product} }++;
  }
  return \%productForBadPrimer;
}

sub _ReadPrimerFile {
  my ( $class, $file ) = @_;

  my @primers;

  # NOTE:
  # - older files might not have this header
  # - will use it to check header
  my @expHeader = qw/Primer_number Forward_primer Forward_Tm Forward_GC
    Reverse_primer Reverse_Tm Reverse_GC Chr Forward_start_position
    Forward_stop_position Reverse_start_position Reverse_stop_position
    Product_length Product_GC Product_tm Product/;
  my ( %header, @NotFoundFields );
  my $poolCount = -1;

  my @lines = path($file)->lines( { chomp => 1 } );
  for my $lineCount ( 0 .. $#lines ) {
    my $line         = $lines[$lineCount];
    my @fields       = split /\t/, $line;
    my %fieldPresent = map { $_ => 1 } @fields;
    if ( !%header ) {
      for my $eField (@expHeader) {
        if ( !exists $fieldPresent{$eField} ) {
          push @NotFoundFields, $eField;
        }
      }
      # legacy files don't have a header but start with the Primer_number
      if ( $fields[0] =~ m/\A\d+/ ) {
        %header = map { $expHeader[$_] => $_ } ( 0 .. $#expHeader );
      }
      # newer format has a header so skip to the next line after grabbing the header
      elsif ( !@NotFoundFields ) {
        %header = map { $fields[$_] => $_ } ( 0 .. $#fields );
        next;
      }
      else {
        my $msg = "Cannot find fields: ";
        $msg .= "'" . join( "', '", @NotFoundFields ) . "'";
        croak $msg;
      }
    }
    my %data = map { $_ => $fields[ $header{$_} ] } ( keys %header );
    my $primerNumber = $data{Primer_number};
    if ( !looks_like_number($primerNumber) ) {
      my $msg =
        sprintf( "Error: no value for expected header Primer_number at line: %d\n\n==> %s",
        ( $lineCount + 1 ), $line );
      croak $msg;
    }

    if ( $primerNumber == 0 ) {
      $poolCount++;
    }
    $data{Pool} = $poolCount;
    my $p = MPD::Primer::Raw->new( \%data );
    push @primers, $p;
  }
  return \@primers;
}

## BUILDARGS takes either a hash reference or string, which is a primer file
#sub BUILDARGS {
#  my $class = shift;
#
#  if ( scalar @_ == 1 ) {
#    if ( !reftype( $_[0] ) ) {
#      my $msg =
#        "Error: Construct MPD::Primer object a hashref { ok => primer_file, bad => primer_file }";
#      croak $msg;
#    }
#    elsif ( reftype( $_[0] ) eq "ARRAY" ) {
#      my $msg =
#        "Error: Construct MPD::Primer object a hashref { ok => primer_file, bad => primer_file }";
#      croak $msg;
#    }
#    elsif ( reftype( $_[0] ) eq "HASH" ) {
#      return $class->SUPER::BUILDARGS( $class->_readOKBadPrimerFiles($_[0]) );
#    }
#    else {
#      my $msg =
#        "Error: Construct MPD::Primer object a hashref { ok => primer_file, bad => primer_file }";
#      croak $msg;
#    }
#  }
#  else {
#    my $msg =
#      "Error: Construct MPD::Primer object a hashref { ok => primer_file, bad => primer_file }";
#    croak $msg;
#  }
#}
#
#sub _readOKBadPrimerFiles {
#  my ($class, $href) = @_;
#
#  my @missingKeys;
#  my @expKeys = qw/ ok bad /;
#  for my $expKey ( @expKeys ) {
#    if (!exists $href->{$expKey} ) {
#      push @missingKeys, $expKey;
#    }
#  }
#  if ( scalar @missingKeys > 0 ) {
#    my $msg = sprintf("Error expected hash reference to have 'ok' and 'bad' keys missing: %s",
#      @missingKeys);
#    croak $msg;
#  }
#
#  my @okPrimers = $class->_readPrimerFile( $href->{ok}, 0 );
#  my @badPrimers = $class->_readPrimerFile( $href->{bad}, 1 );
#
#  my @primers = (@okPrimers, @badPrimers);
#  my @sortPrimers = map { $_->[0] } sort { $a->[1] <=> $b->[1] } map { [ $_, $_->{Primer_number} ] } @primers;
#
#  my @primerObjs;
#  my $poolCount = 0;
#
#  for my $href ( @sortPrimers ) {
#    if ( $href->{Primer_number} == 0 ) {
#      $poolCount++;
#    }
#    $href->{Pool} = $poolCount;
#    push @primerObjs, MPD::Primer::Raw->new($href);
#  }
#  return { Primers => \@primerObjs };
#}
#
#sub _readPrimerFile {
#  my ($class, $file, $PrimerQcCode) = @_;
#
#  my @primers;
#
#  my $fh = path($file)->filehandle();
#  my %header;
#
#  while (<$fh>) {
#    chomp $_;
#    my @fields = split /\t/, $_;
#    if (!%header ) {
#      %header = map { $fields[$_] => $_ } (0..$#fields);
#      next;
#    }
#    my %data = map { $_ => $fields[$header{$_}] } (keys %header);
#    $data{BadPrimer} = $PrimerQcCode;
#    push @primers, \%data;
#  }
#  if ( wantarray ) {
#    return @primers;
#  } elsif ( defined wantarray ){
#    return \@primers;
#  } else {
#    my $msg = "Error: _readPrimerFile() called in void context.";
#    croak $msg;
#  }
#}
#
__PACKAGE__->meta->make_immutable;

1;
