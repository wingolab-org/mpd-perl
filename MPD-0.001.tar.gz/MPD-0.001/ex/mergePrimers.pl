#!/usr/bin/env perl
# Name:           mergePrimers.pl
# Date Created:   Thu Apr 14 22:46:03 2016
# Date Modified:  Thu Apr 14 22:46:03 2016
# By:             TS Wingo
#
# Description:

use lib '/Users/twingo/software/mpd-perl/lib/';
use 5.10.0;
use warnings;
use strict;

use Getopt::Long;
use Path::Tiny;
use MPD::Primer;
use MPD::isPcr;
use MPD::Bed;

use Data::Dump qw/ dump /; # for debugging

# variables
my ( $verbose, $act, $file_name, $out_ext, $project_name );
my $isPcrBinaryFile = "/Users/twingo/local/bin/isPcr";
my $twoBitFile      = "/Users/twingo/data/hg38.2bit";

# get options
die "Usage: $0 [-v] [-a] -f <file_name> [-o <out_ext>]\n"
  unless GetOptions(
  'v|verbose'   => \$verbose,
  'a|act'       => \$act,
  'f|file=s'    => \$file_name,
  'o|out=s'     => \$out_ext,
  'p|project=s' => \$project_name,
  )
  and $project_name
  and $file_name
  and $out_ext;
$verbose++ unless $act;

# Files
my @primerFiles = ("$file_name");

# get the design with most primers/pool 1st
my @bedFiles = ( 'geneList.txt.bed', );

# main
my $mergePrimerFile = path("$out_ext.primer.txt");
my $mergeBedFile    = path("$out_ext.bed");
MergePrimerFiles( $mergePrimerFile, \@primerFiles );
MergeBedFiles( $mergeBedFile, \@bedFiles );
my $prnOptHref = prnOpt( $mergeBedFile->stringify() );
WritePrimer( $mergePrimerFile->stringify(), $out_ext, $prnOptHref );

# subroutines
sub prnOpt {
  my $bedFile = shift;

  my $bedObj = MPD::Bed->new($bedFile);
  my %prnOpt = (
    FwdAdapter => 'ACACTGACGACATGGTTCTACA',
    RevAdapter => 'TACGGTAGCAGAGACTTGGTCT',
    #Randomize   => 1,
    ProjectName => $project_name,
    MaxPlates   => 99,
    Bed         => $bedObj,
  );
  return \%prnOpt;
}

sub MergePrimerFiles {
  my $mergeFile = shift;
  my $filesAref = shift;

  my $mFh = $mergeFile->filehandle(">");
  my $header;

  for my $f (@$filesAref) {
    my @lines = path($f)->lines( { chomp => 1 } );
    if ( !$header ) {
      say {$mFh} join "\n", @lines;
      $header = 1;
    }
    else {
      say {$mFh} join "\n", @lines[ 1 .. $#lines ];
    }
  }
}

sub MergeBedFiles {
  my $mergeFile = shift;
  my $filesAref = shift;

  my $mFh = $mergeFile->filehandle(">");

  for my $f (@$filesAref) {
    my @lines = path($f)->lines( { chomp => 1 } );
    say {$mFh} join "\n", @lines;
  }
}

sub CleanPrimers {
  my $file = shift;

  my $outFile = Path::Tiny->tempfile();
  my $isPcr   = MPD::isPcr->new(
    {
      PrimerFile       => $file,
      PrimerFileFormat => 'mpp',
      isPcrBinary      => $isPcrBinaryFile,
      TwoBitFile       => $twoBitFile,
      OutFile          => $outFile->stringify(),
    }
  );
  $isPcr->Run();

  my %badPrimers;

  my $psl     = MPD::Psl->new( $outFile->stringify() );
  my $dupAref = $psl->DegenerateMatches();
  $badPrimers{$_}++ for @$dupAref;

  my $p = MPD::Primer->new($file);
  $dupAref = $p->DuplicatePrimers();
  $badPrimers{$_}++ for @$dupAref;

  if ( !%badPrimers ) {
    return $p;
  }
  return $p->RemovePrimers( [ sort keys %badPrimers ] );
}

sub WritePrimer {
  my $mergeFile  = shift;
  my $OutExt     = shift;
  my $prnOptHref = shift;

  my $p   = CleanPrimers($mergeFile);
  my $dir = path(".");

  my $forOrderPt = $dir->child( sprintf( "%s.forOrder.xlsx", $OutExt ) );
  my $primerCount = $p->WriteOrderFile( $forOrderPt->stringify(), $prnOptHref );
  say $primerCount;

  my $primerPt = $dir->child( sprintf( "%s.primer.txt", $OutExt ) );
  $p->WritePrimerFile( $primerPt->stringify(), $primerCount );

  my $isPcrPt = $dir->child( sprintf( "%s.isPcr.txt", $OutExt ) );
  $p->WriteIsPcrFile( $isPcrPt->stringify(), $primerCount );

  my $coveredPt = $dir->child( sprintf( "%s.covered.bed", $OutExt ) );
  $p->WriteCoveredFile( $coveredPt->stringify(), $prnOptHref->{Bed} );

  CleanCoveredFile( $coveredPt->stringify() );

  my $uncoveredPt = $dir->child( sprintf( "%s.uncovered.bed", $OutExt ) );
  $p->WriteUncoveredFile( $uncoveredPt->stringify, $prnOptHref->{Bed} );
}

sub CleanCoveredFile {
  my $file = shift;

  my @lines = path($file)->lines( { chomp => 1 } );
  my $fh = path($file)->filehandle(">");

  for my $line (@lines) {
    my @fields = split /\t/, $line;
    if ( $fields[4] ne 'NA' ) {
      say {$fh} join "\t", @fields;
    }
  }
}
