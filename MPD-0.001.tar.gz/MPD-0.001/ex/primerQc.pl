#!/usr/bin/env perl
# Name:           primerQc.pl
# Date Created:   Fri Aug  5 08:58:50 2016
# Date Modified:  Fri Aug  5 08:58:50 2016
# By:             TS Wingo
#
# Description:


use 5.10.0;
use warnings;
use strict;
use lib './lib';

use Getopt::Long;
use Path::Tiny;
use Data::Dump qw/ dump /;
use MPD::PrimerQc;

# variables
my ($primerFile, $badPrimerFile);

# get options
die "Usage: $0 -primer <primerFile>, -bad <badPrimerFile>\n"
  unless GetOptions(
    'primer=s' => \$primerFile,
    'bad=s' => \$badPrimerFile,
    ) and $primerFile and $badPrimerFile;

my $obj = MPD::PrimerQc->new($primerFile);
$obj->BadPrimerPerPool($badPrimerFile);

